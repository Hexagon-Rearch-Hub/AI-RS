package constant

const (
	ALI_WEB = iota + 1
	ALI_APP
	WECHAT
)
